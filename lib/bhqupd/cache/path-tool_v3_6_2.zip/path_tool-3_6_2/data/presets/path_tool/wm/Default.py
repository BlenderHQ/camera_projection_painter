import bpy
props = bpy.context.window_manager.select_path

props.mark_select = 'EXTEND'
props.mark_seam = 'NONE'
props.mark_seam = 'NONE'
props.use_topology_distance = False
